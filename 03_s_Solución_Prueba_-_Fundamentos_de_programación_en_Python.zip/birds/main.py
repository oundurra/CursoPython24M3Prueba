from get_module import request_get
import templates as t

# Paso 4
def build_html(url):
    response = request_get(url)
    texto = ''
    for resultados in response:
        
        texto += t.elem_template.substitute(
                              title_es = resultados['name']['spanish'],
                                title_en = resultados['name']['english'],
                                url = resultados['images']['main'])
    
    return t.html_template.substitute(body = texto)

if __name__ == '__main__':
    # Paso 5
    html = build_html('https://aves.ninjas.cl/api/birds')
    with open('output.html','w') as f:
        f.write(html)